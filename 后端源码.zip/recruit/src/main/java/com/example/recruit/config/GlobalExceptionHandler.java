package com.example.recruit.config;

import com.example.recruit.exception.LocalRuntimeException;
import com.example.recruit.response.MyResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author: scarborough
 * @datetime: 2023/9/27 - 10:09
 */
@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);



    /**
     * 处理自定义异常
     *
     */
    @ExceptionHandler(value = LocalRuntimeException.class)
    public MyResponse bizExceptionHandler(LocalRuntimeException e) {
        log.error(e.getMessage(), e);
        return MyResponse.error(e);
    }
}
