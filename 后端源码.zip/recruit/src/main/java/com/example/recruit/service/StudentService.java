package com.example.recruit.service;

import java.util.List;
import java.util.Map;

public interface StudentService {

    Map<String, Object> getList(String stu_id, Long unitId);

    void commitAnswer(String stuId, Long unitId, Long problemId, String answer);

    List<Map<String,Object>> getHistoryScore(String stuId);
}
