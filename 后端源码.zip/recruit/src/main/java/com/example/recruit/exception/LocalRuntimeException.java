package com.example.recruit.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author scarborough
 * @creat 2022/11/2 - 20:22
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class LocalRuntimeException extends RuntimeException {
    /** 错误状态码 */
    protected Integer errorCode;
    /** 错误提示 */
    protected String errorMsg;
    public LocalRuntimeException(){}

    public LocalRuntimeException(Integer errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }


    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
}
