package com.example.recruit.enetity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author scarborough
 * @creat 2022/11/3 - 15:44
 */
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Unit {

    //声明主键为id自增
    @TableId(type = IdType.AUTO)
    private Long id;

    private String unitName;

    private String unitDescription;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime startTime;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime endTime;

    private Integer totalScore;
}
