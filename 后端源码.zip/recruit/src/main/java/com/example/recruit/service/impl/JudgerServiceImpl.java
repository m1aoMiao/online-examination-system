package com.example.recruit.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.recruit.enetity.Account;
import com.example.recruit.enetity.Answer;
import com.example.recruit.enetity.Problem;
import com.example.recruit.enetity.Unit;
import com.example.recruit.exception.LocalRuntimeException;
import com.example.recruit.info.ProblemInfo;
import com.example.recruit.info.ScoreInfo;
import com.example.recruit.info.StuInfo;
import com.example.recruit.mapper.AccountMapper;
import com.example.recruit.mapper.AnswerMapper;
import com.example.recruit.mapper.ProblemMapper;
import com.example.recruit.mapper.UnitMapper;
import com.example.recruit.response.ErrEnum;
import com.example.recruit.response.MyResponse;
import com.example.recruit.service.JudgerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author scarborough
 * @creat 2022/11/8 - 18:55
 */
@Service
public class JudgerServiceImpl implements JudgerService {
    @Autowired
    private AnswerMapper answerMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private ProblemMapper problemMapper;

    @Autowired
    private UnitMapper unitMapper;

    //阅卷人-得到答题信息列表
    @Override
    public MyResponse getList(Long unitId) {
        Integer unitScore = 0;
        //新建Map，用来存放data信息
        Map<String, Object> map = new HashMap<>();
        //新建List，用来存放学生答题信息
        List<StuInfo> stuInfos = new ArrayList<>();

        //查询数据库中所有题目数，并存放到map中
        Long totalProblemNum = answerMapper.selectCount(null);
        map.put("total_problem_num", totalProblemNum);
        //查询数据库中所有已经被批改过的题目数，并放到map中
        Long totalJudgedNum = answerMapper.selectAllFinishedCount(unitId);
        map.put("total_judged_num", totalJudgedNum);
        //查询所有已经答题的账号数账号数,并放到map中
        Long totalAnsweredAccountNum = answerMapper.selectTotalAnsweredAccountNum();
        map.put("total_answered_account_num", totalAnsweredAccountNum);
        //得到答题人账号信息，并遍历
        LambdaQueryWrapper<Account> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Account::getRole, 0);
        List<Account> stuList = accountMapper.selectList(lambdaQueryWrapper);
        for (Account account : stuList) {



            //此人已经完成的问题数
            Integer finishedQuestionNum = answerMapper.selectFinishedQuestionNum(account.getStuId(),unitId);
            //此人总共需要完成的问题数
            Long totalQuestionNum = problemMapper.selectCount(Wrappers.<Problem>lambdaQuery()
                    .eq(Problem::getUnitId,unitId));
            //此人已经被批改的问题数
            Integer finishedCorrectNum = answerMapper.selectFinishedCorrectNum(unitId, account.getStuId());

            //实例化一个StuInfo,用来存放当前当前学生答题信息
            StuInfo stuInfo = new StuInfo();
            stuInfo.setStuId(account.getStuId());
            stuInfo.setStuName(account.getStuName());
            stuInfo.setFinishedQuestionNum(finishedQuestionNum);
            stuInfo.setTotalQuestionNum(totalQuestionNum);
            stuInfo.setFinishedCorrectNum(finishedCorrectNum);
            // 得到当前比赛分数
            List<Problem> problemList = problemMapper.selectList(Wrappers.<Problem>lambdaQuery()
                    .eq(Problem::getUnitId,unitId));
            for (Problem problem :
                    problemList) {
                if(answerMapper.exists(Wrappers.<Answer>lambdaQuery()
                        .eq(Answer::getStuId,account.getStuId())
                        .eq(Answer::getProblemId,problem.getId()))){
                    unitScore+=answerMapper.selectOne(Wrappers.<Answer>lambdaQuery()
                            .eq(Answer::getStuId,account.getStuId())
                            .eq(Answer::getProblemId,problem.getId())).getCorrectScore();
                }
            }
            stuInfo.setUnitScore(unitScore);
            stuInfo.setTotalScore(unitMapper.selectById(unitId).getTotalScore());
            //将当前学生答题信息加入到judgerInfos中
            stuInfos.add(stuInfo);

        }

        //所有学生账号数
        map.put("total_account_num", stuList.size());
        //将学生答题信息存到map中
        map.put("stu_list", stuInfos);

        //返回成功信息
        return MyResponse.success("得到答题信息列表", 200, map);
    }

    //阅卷人-得到具体某个人的答题情况
    @Override
    public MyResponse getOne(Long unitId, String stuId) {
        //新建Map，用来存放data信息
        Map<String, Object> map = new HashMap<>();
        //新建List，用来存放学生答题信息
        List<ProblemInfo> problemInfos = new ArrayList<>();

        //查询比赛名字，放入map中
        LambdaQueryWrapper<Unit> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Unit::getId, unitId);
        Unit unit = unitMapper.selectOne(lambdaQueryWrapper);
        map.put("unit_name", unit.getUnitName());
        //查询比赛描述信息，放入map中
        map.put("unit_description", unit.getUnitDescription());

        //得到所有题目，并遍历
        LambdaQueryWrapper<Problem> lambdaProQueryWrapper = new LambdaQueryWrapper<>();
        lambdaProQueryWrapper.eq(Problem::getUnitId, unitId);
        List<Problem> problemList = problemMapper.selectList(lambdaProQueryWrapper);
        for (Problem problem : problemList) {

            //得到当前学生当前题目的答案
            QueryWrapper<Answer> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("stu_id", stuId);
            queryWrapper1.eq("problem_id", problem.getId());
            Answer answer = answerMapper.selectOne(queryWrapper1);

            //实例化一个ProblemInfo,用来存放当前题目信息
            ProblemInfo problemInfo = new ProblemInfo();
            //设置题目类别
            switch (problem.getProblemType()){
                case 0:
                    problemInfo.setProblemType("单选题");
                    break;
                case 1:
                    problemInfo.setProblemType("多选题");
                    break;
                case 2:
                    problemInfo.setProblemType("简答题");
                    break;

            }
            //设置题目组别
            switch (problem.getProblemGroup()){
                case 1:
                    problemInfo.setProblemGroup("前端组");
                    break;
                case 2:
                    problemInfo.setProblemGroup("后端组");
                    break;
                case 3:
                    problemInfo.setProblemGroup("python组");
                    break;
                case 4:
                    problemInfo.setProblemGroup("算法组");
                    break;
                case 5:
                    problemInfo.setProblemGroup("安全组");
                    break;

            }
            //设置题目描述
            problemInfo.setProblemDescription(problem.getProblemDescription());
            if(answer != null){
                problemInfo.setAnswer(answer.getAnswer());
                problemInfo.setProblemScore(answer.getCorrectScore());
            }else{
                problemInfo.setAnswer("");
            }
            problemInfo.setProblemId(problem.getId());
            problemInfo.setOptionA(problem.getOptionA());
            problemInfo.setOptionB(problem.getOptionB());
            problemInfo.setOptionC(problem.getOptionC());
            problemInfo.setOptionD(problem.getOptionD());
            problemInfo.setPictureUrl(problem.getPictureUrl());
            //将当前题目信息加入到problemInfos中
            problemInfos.add(problemInfo);

        }
        map.put("problem_list", problemInfos);

        return MyResponse.success("得到具体某个人的答题情况", 200, map);
    }

    //阅卷人-批改
    @Override
    public MyResponse correct(Long unitId, String stuId, List<ScoreInfo> scoreInfos, String judgerId) {
        //创建五个变量，分别存储五个组别的得分
        int frontEndScore = 0;
        int backEndScore = 0;
        int pythonScore = 0;
        int algorithmScore = 0;
        int securityScore = 0;
        //根据学号查询学生账号信息
        LambdaUpdateWrapper<Account> accountLambdaUpdateWrapper = new LambdaUpdateWrapper<>();
        accountLambdaUpdateWrapper.eq(Account::getStuId, stuId);
        //循环遍历每一道题
        for (ScoreInfo scoreInfo :
                scoreInfos) {
            //查询answer表中对应学号和题目ID的学生
            LambdaUpdateWrapper<Answer> lambdaUpdateWrapper = new LambdaUpdateWrapper<>();
            lambdaUpdateWrapper.eq(Answer::getStuId, stuId);
            lambdaUpdateWrapper.eq(Answer::getProblemId, scoreInfo.getProblemId());
            //根据题目ID查询题目，实例化Problem，为下面判断题目组别从而打分提供基础
            LambdaQueryWrapper<Problem> problemLambdaQueryWrapper = new LambdaQueryWrapper<>();
            problemLambdaQueryWrapper.eq(Problem::getId, scoreInfo.getProblemId());
            Problem thisProblem = problemMapper.selectOne(problemLambdaQueryWrapper);

            if(scoreInfo.getScore()>thisProblem.getProblemScore()){
                throw new LocalRuntimeException(ErrEnum.ERR_RANGE.getErrCode(), ErrEnum.ERR_RANGE.getErrMsg());
            }

            //如果这个学生答了这题，则执行打分功能和计算各组题目得分
            if (answerMapper.exists(lambdaUpdateWrapper)) {
                //判断本题属于的组别，计算各组得分
                if (thisProblem.getProblemGroup() == 1) {
                    frontEndScore += scoreInfo.getScore();
                }
                if(thisProblem.getProblemGroup() == 2){
                    backEndScore+=scoreInfo.getScore();
                }
                if(thisProblem.getProblemGroup() == 3){
                    pythonScore+=scoreInfo.getScore();
                }
                if(thisProblem.getProblemGroup() == 4){
                    algorithmScore+=scoreInfo.getScore();
                }
                if(thisProblem.getProblemGroup() == 5){
                    securityScore+=scoreInfo.getScore();
                }
                //打分
                answerMapper.update(null, lambdaUpdateWrapper.set(Answer::getCorrectScore, scoreInfo.getScore()));
                answerMapper.update(null, lambdaUpdateWrapper.set(Answer::getJudgerId,judgerId));
            }
        }
        //更新各组分数
        accountMapper.update(null,accountLambdaUpdateWrapper.set(Account::getFrontEndScore,frontEndScore));
        accountMapper.update(null,accountLambdaUpdateWrapper.set(Account::getBackEndScore,backEndScore));
        accountMapper.update(null,accountLambdaUpdateWrapper.set(Account::getPythonScore,pythonScore));
        accountMapper.update(null,accountLambdaUpdateWrapper.set(Account::getAlgorithmScore,algorithmScore));
        accountMapper.update(null,accountLambdaUpdateWrapper.set(Account::getSecurityScore,securityScore));

        //返回成功结果
        return MyResponse.success("打分提交成功", 200, null);
    }
}
