package com.example.recruit.response;

/**
 * @author scarborough
 * @creat 2022/11/14 - 17:20
 */
public enum ErrEnum {
    //错误码
    ERR_FILE_FORM(400,"错误的文件格式"),
    ERR_ROLE(400,"错误的身份"),
    NO_ARGS(400,"传参为空"),
    ERR_RANGE(400,"错误的分数"),
    REPEATED_ACCOUNTS(400,"重复导入文件"),
    UNAUTHORIZED_TIME(401,"不允许的时间"),
    UN_AUTHORIZED(401,"无权限"),
    NO_UNIT(404,"不存在的比赛"),
    NO_PROBLEM(404,"不存在的题目"),
    NO_USER(404,"不存在的用户"),
    NO_PERMISSION(403,"密码错误"),
    REPEATED_UNIT(409,"比赛已存在"),
    REPEATED_USER(409,"用户已存在"),
    ERR_UPDATE(500,"更新失败"),
    ERR_DELETE(500,"删除失败"),
    ERR_IMPORT(500,"导入失败")
    ;

    private final Integer errCode;
    private final String errMsg;


    ErrEnum(Integer errCode, String errMsg) {
        this.errCode = errCode;
        this.errMsg = errMsg;
    }

    public Integer getErrCode() {
        return errCode;
    }

    public String getErrMsg() {
        return errMsg;
    }
}
