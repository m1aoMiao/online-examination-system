package com.example.recruit.controller;

import com.example.recruit.enetity.Account;
import com.example.recruit.exception.LocalRuntimeException;
import com.example.recruit.info.ScoreInfo;
import com.example.recruit.response.ErrEnum;
import com.example.recruit.response.MyResponse;
import com.example.recruit.service.JudgerService;
import com.example.recruit.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @author scarborough
 * @creat 2022/11/8 - 18:52
 */
@Slf4j
@RestController
@RequestMapping("/judger")
public class JudgerController {

    @Autowired
    private JudgerService judgerService;

    //阅卷人-得到答题信息列表
    @GetMapping("/getList")
    public MyResponse getList(@RequestParam @NotNull Long unitId, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() == 0) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return judgerService.getList(unitId);
    }

    //阅卷人-得到具体某个人的答题情况
    @GetMapping("/getOne")
    public MyResponse getOne(@RequestParam @NotNull Long unitId, @RequestParam @NotNull String stuId, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() == 0) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return judgerService.getOne(unitId, stuId);
    }

    //阅卷人-批改
    @PostMapping("/correct")
    public MyResponse correct(@NotNull HttpServletRequest httpServletRequest, @RequestParam @NotNull Long unitId, @RequestParam @NotNull String stuId, @RequestBody List<ScoreInfo> scoreInfos) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() == 0) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        String judgerId = account.getStuId();
        return judgerService.correct(unitId, stuId, scoreInfos, judgerId);
    }
}
