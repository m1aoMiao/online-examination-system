package com.example.recruit.utils;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClientBuilder;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.logging.Logger;
import org.mybatis.logging.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;


/**
 * @author scarborough
 * @creat 2022/11/9 - 21:42
 */
@Slf4j
@Component
public class OSSUtil {

    @Value("${aliyun.endpoint}")
    private String endpoint;

    @Value("${aliyun.access-key-id}")
    private String accessKeyId;

    @Value("${aliyun.access-key-secret}")
    private String accessKeySecret;

    @Value("${aliyun.bucket}")
    private String bucket;

    public String uploadFile(MultipartFile multipartFile) {
        log.info("------------OSS上传文件-------------");
        // 创建OSSClient实例。
        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
        try {
            //得到当前日期
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String datePath = dateFormat.format(new Date());
            //获得文件输入流
            InputStream inputStream = multipartFile.getInputStream();
            //获得文件名，重新生成文件名
            String originName = multipartFile.getOriginalFilename();
            String fileName = UUID.randomUUID().toString();

            assert originName != null;
            String suffix = originName.substring(originName.lastIndexOf("."));
            String newName = fileName + suffix;
            String fileUrl = datePath + newName;
            ossClient.putObject(bucket, fileUrl, inputStream);
            String url = "http://" + bucket+"."+ endpoint + "/" + fileUrl;
            return url;
        } catch (Exception e) {
            e.printStackTrace();
            return "fail";
        } finally {
            if (ossClient != null) {
                ossClient.shutdown();
            }
        }
    }
}
