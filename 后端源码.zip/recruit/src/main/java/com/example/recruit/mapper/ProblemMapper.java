package com.example.recruit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.recruit.enetity.Problem;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author scarborough
 * @creat 2022/11/4 - 16:17
 */
@Mapper
public interface ProblemMapper extends BaseMapper<Problem> {
}
