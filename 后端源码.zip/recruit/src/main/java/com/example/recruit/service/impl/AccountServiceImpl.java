package com.example.recruit.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.recruit.enetity.Account;
import com.example.recruit.enetity.Unit;
import com.example.recruit.mapper.AccountMapper;
import com.example.recruit.mapper.UnitMapper;
import com.example.recruit.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class AccountServiceImpl extends ServiceImpl<AccountMapper, Account> implements AccountService {
    @Autowired
    private UnitMapper unitMapper;
    @Override
    public List<Object> getUnit(){
        List<Unit> units = unitMapper.selectList(null);
        List<Object> Units = new ArrayList<>();
        for(Unit unit: units){
            Map<String, Object> map = new HashMap<>();
            map.put("unit_id", unit.getId());
            map.put("unit_name", unit.getUnitName());
            map.put("unit_description", unit.getUnitDescription());
            map.put("start_time", unit.getStartTime());
            map.put("end_time", unit.getEndTime());
            LocalDateTime date = LocalDateTime.now();
            if(date.isBefore(unit.getEndTime())&&date.isAfter(unit.getStartTime())) {
                map.put("isLate",false);
            } else {
                map.put("isLate",true);
            }
            Units.add(map);
        }

        return Units;
    }
}
