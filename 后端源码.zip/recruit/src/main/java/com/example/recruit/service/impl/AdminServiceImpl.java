package com.example.recruit.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.recruit.enetity.Account;
import com.example.recruit.enetity.Answer;
import com.example.recruit.enetity.Problem;
import com.example.recruit.enetity.Unit;
import com.example.recruit.exception.LocalRuntimeException;
import com.example.recruit.info.JudgerInfo;
import com.example.recruit.mapper.AccountMapper;
import com.example.recruit.mapper.AnswerMapper;
import com.example.recruit.mapper.ProblemMapper;
import com.example.recruit.mapper.UnitMapper;
import com.example.recruit.response.ErrEnum;
import com.example.recruit.response.MyResponse;
import com.example.recruit.service.AdminService;
import com.example.recruit.utils.ExcelUtil;
import com.example.recruit.utils.OSSUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.*;


/**
 * @author scarborough
 * @creat 2022/11/5 - 14:09
 */
@Slf4j
@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private ProblemMapper problemMapper;

    @Autowired
    private UnitMapper unitMapper;

    @Autowired
    private AccountMapper accountMapper;

    @Autowired
    private AnswerMapper answerMapper;

    @Autowired
    private ExcelUtil excelUtil;

    @Autowired
    private OSSUtil ossUtil;

    //添加比赛
    @Override
    public MyResponse addUnit(Unit unit) {

        //传递参数不能为空
        if (unit.getUnitName() == null || unit.getUnitDescription() == null || unit.getStartTime() == null || unit.getEndTime() == null) {
            throw new LocalRuntimeException(ErrEnum.NO_ARGS.getErrCode(), ErrEnum.NO_ARGS.getErrMsg());
        }
        if (unit.getStartTime().isAfter(unit.getEndTime())) {
            throw new LocalRuntimeException(ErrEnum.UNAUTHORIZED_TIME.getErrCode(), ErrEnum.UNAUTHORIZED_TIME.getErrMsg());
        }

        //创建QueryWrapper，查找传过来的unit_name的实体在库里是否有记录
        LambdaQueryWrapper<Unit> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Unit::getUnitName, unit.getUnitName());
        Unit one = unitMapper.selectOne(lambdaQueryWrapper);
        //若查询的记录不为空，抛出异常
        if (one != null) {
            throw new LocalRuntimeException(ErrEnum.REPEATED_UNIT.getErrCode(), ErrEnum.REPEATED_UNIT.getErrMsg());
        }
        //向数据库插入传过来的unit
        unit.setTotalScore(0);
        unitMapper.insert(unit);
        //返回成功信息
        return MyResponse.success("新建比赛成功", 200, null);
    }

    //修改比赛
    @Override
    public MyResponse updateUnit(Long unitId, Unit unit) {

        if (unit.getStartTime().isAfter(unit.getEndTime())) {
            throw new LocalRuntimeException(ErrEnum.UNAUTHORIZED_TIME.getErrCode(), ErrEnum.UNAUTHORIZED_TIME.getErrMsg());
        }

        try {
            //通过updateWrapper寻找库中对应id的记录
            LambdaUpdateWrapper<Unit> lambdaUpdateWrapper = new LambdaUpdateWrapper<>();
            lambdaUpdateWrapper.eq(Unit::getId, unitId);
            //如果updateWrapper得到的信息存在，执行更新操作
            if (unitMapper.exists(lambdaUpdateWrapper)) {
                //执行更新操作
                unitMapper.update(null, lambdaUpdateWrapper.set(Unit::getUnitName, unit.getUnitName()));
                unitMapper.update(null, lambdaUpdateWrapper.set(Unit::getUnitDescription, unit.getUnitDescription()));
                unitMapper.update(null, lambdaUpdateWrapper.set(Unit::getStartTime, unit.getStartTime()));
                unitMapper.update(null, lambdaUpdateWrapper.set(Unit::getEndTime, unit.getEndTime()));
            }
            //返回成功信息
            return MyResponse.success("修改比赛成功", 200, null);
        } catch (Exception e) {
            throw new LocalRuntimeException(ErrEnum.ERR_UPDATE.getErrCode(), ErrEnum.ERR_UPDATE.getErrMsg());
        }
    }

    //删除比赛
    @Override
    public MyResponse deleteUnit(Long unitId) {
        try {
            //删掉比赛
            LambdaQueryWrapper<Unit> unitLambdaQueryWrapper = new LambdaQueryWrapper<>();
            unitLambdaQueryWrapper.eq(Unit::getId, unitId);
            if (unitMapper.exists(unitLambdaQueryWrapper)) {
                unitMapper.delete(unitLambdaQueryWrapper);
            }
            //删掉比赛还要删掉其关联下的题目和答案
            LambdaQueryWrapper<Problem> problemLambdaQueryWrapper = new LambdaQueryWrapper<Problem>();
            LambdaQueryWrapper<Answer> answerLambdaQueryWrapper = new LambdaQueryWrapper<>();
            problemLambdaQueryWrapper.eq(Problem::getUnitId, unitId);
            answerLambdaQueryWrapper.eq(Answer::getUnitId, unitId);

            if (problemMapper.exists(problemLambdaQueryWrapper)) {
                problemMapper.delete(problemLambdaQueryWrapper);
            }

            if (answerMapper.exists(answerLambdaQueryWrapper)) {
                answerMapper.delete(answerLambdaQueryWrapper);
            }
            //返回成功信息
            return MyResponse.success("删除成功", 200, null);
            //失败抛出异常
        } catch (Exception e) {
            throw new RuntimeException("删除失败");
        }
    }

    //上传题目
    @Override
    public MyResponse addProblem(Long unitId, String problemDescription, Integer problemType, Integer problemScore, Integer problemGroup, String optionA, String optionB, String optionC, String optionD, MultipartFile[] picture, String answer) {
        log.info("上传题目————————————————————————————————————————————————————");
        log.info(String.valueOf(picture.length));
        log.info("picture数组的长度：" + picture.length);
        //创建一个StringBuffer容器，用来拼接url
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < picture.length; i++) {
            if (!picture[i].isEmpty()) {
                //调用oss工具类的上传文件方法，将图片的url保存下来
                String url = ossUtil.uploadFile(picture[i]);
                //拼接url操作
                if (i != picture.length - 1) {
                    sb.append(url).append("|");
                } else {
                    sb.append(url);
                }
            }

        }

        //判断unitId对应的比赛是否存在，若不存在，返回信息
        LambdaQueryWrapper<Unit> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Unit::getId, unitId);
        if (!(unitMapper.exists(lambdaQueryWrapper))) {
            throw new LocalRuntimeException(ErrEnum.NO_UNIT.getErrCode(), ErrEnum.NO_UNIT.getErrMsg());
        }
        //判断题目类型执行插入操作
        if (problemType == 2 || problemType == 3 || problemType == 4) {
            problemMapper.insert(new Problem(unitId, problemDescription, problemType, problemScore, problemGroup, sb.toString(), answer));
        }
        if (problemType == 0 || problemType == 1) {
            problemMapper.insert(new Problem(unitId, problemDescription, problemType, problemScore, problemGroup, optionA, optionB, optionC, optionD, sb.toString(), answer));
        }

        //返回成功信息
        return MyResponse.success("上传题目成功", 200, null);

    }

    @Override
    public MyResponse addProblem(Long unitId, String problemDescription, Integer problemType, Integer problemScore, Integer problemGroup, String optionA, String optionB, String optionC, String optionD, String answer) {
        log.info("上传题目——没图片——————————————————————————————————————————————————");


        //判断unitId对应的比赛是否存在，若不存在，返回信息
        LambdaQueryWrapper<Unit> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Unit::getId, unitId);
        if (!(unitMapper.exists(lambdaQueryWrapper))) {
            throw new LocalRuntimeException(ErrEnum.NO_UNIT.getErrCode(), ErrEnum.NO_UNIT.getErrMsg());
        }
        //判断题目类型执行插入操作
        if (problemType == 2 || problemType == 3 || problemType == 4) {
            problemMapper.insert(new Problem(unitId, problemDescription, problemType, problemScore, problemGroup, null, answer));
        }
        if (problemType == 0 || problemType == 1) {
            problemMapper.insert(new Problem(unitId, problemDescription, problemType, problemScore, problemGroup, optionA, optionB, optionC, optionD, null, answer));
        }

        // 更新比赛总分
        unitMapper.update(null, Wrappers.<Unit>lambdaUpdate()
                .eq(Unit::getId, unitId)
                .set(Unit::getTotalScore, unitMapper.selectById(unitId).getTotalScore() + problemScore));

        //返回成功信息
        return MyResponse.success("上传题目成功", 200, null);

    }


    //修改题目
    @Override
    public MyResponse updateProblem(Long problemId, String problemDescription, Integer problemType, Integer problemScore, Integer problemGroup, String optionA, String optionB, String optionC, String optionD, MultipartFile[] picture) {
        //创建一个StringBuffer容器，用来拼接url
        StringBuilder sb = new StringBuilder();
        //遍历文件
        for (int i = 0; i < picture.length; ++i) {
            //调用oss工具类的上传文件方法，将图片的url保存下来
            String url = ossUtil.uploadFile(picture[i]);
            //拼接url操作
            if (i != picture.length - 1) {
                sb.append(url).append("|");
            } else {
                sb.append(url);
            }
        }

        //查询数据库中是否存在与unitId和problemId对应的记录
        LambdaUpdateWrapper<Problem> lambdaUpdateWrapper = new LambdaUpdateWrapper<>();
        lambdaUpdateWrapper.eq(Problem::getId, problemId);
        //若不存在，抛出异常
        if (!(problemMapper.exists(lambdaUpdateWrapper))) {
            throw new LocalRuntimeException(ErrEnum.NO_PROBLEM.getErrCode(), ErrEnum.NO_PROBLEM.getErrMsg());
        }
        try {
            //执行更新操作
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getProblemDescription, problemDescription));
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getProblemType, problemType));
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getProblemScore, problemScore));
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getProblemGroup, problemGroup));
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getOptionA, optionA));
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getOptionB, optionB));
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getOptionC, optionC));
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getOptionD, optionD));
            problemMapper.update(null, lambdaUpdateWrapper.set(Problem::getPictureUrl, sb.toString()));
            //返回成功信息
            return MyResponse.success("修改题目成功", 200, null);
            //更新失败，抛出异常
        } catch (Exception e) {
            throw new LocalRuntimeException(ErrEnum.ERR_UPDATE.getErrCode(), ErrEnum.ERR_UPDATE.getErrMsg());
        }


    }

    //删除题目
    @Override
    public MyResponse deleteProblem(Long problemId) {
        try {
            // 将比赛总分减去当前题目分数
            Problem problem = problemMapper.selectById(problemId);
            Unit unit = unitMapper.selectById(problem.getUnitId());
            unit.setTotalScore(unit.getTotalScore() - problem.getProblemScore());
            unitMapper.updateById(unit);
            //删掉题目
            LambdaQueryWrapper<Problem> problemLambdaQueryWrapper = new LambdaQueryWrapper<>();
            problemLambdaQueryWrapper.eq(Problem::getId, problemId);
            if (problemMapper.exists(problemLambdaQueryWrapper)) {
                problemMapper.delete(problemLambdaQueryWrapper);
            }
            //删掉题目还要删掉其下关联的答案
            LambdaQueryWrapper<Answer> answerLambdaQueryWrapper = new LambdaQueryWrapper<>();
            answerLambdaQueryWrapper.eq(Answer::getProblemId, problemId);
            if (answerMapper.exists(answerLambdaQueryWrapper)) {
                answerMapper.delete(answerLambdaQueryWrapper);
            }

            //返回成功信息
            return MyResponse.success("删除题目成功", 200, null);
        } catch (Exception e) {
            throw new LocalRuntimeException(ErrEnum.ERR_DELETE.getErrCode(), ErrEnum.ERR_DELETE.getErrMsg());
        }

    }

    //修改角色
    @Override
    public MyResponse updateRole(String stuId) {
        //查询传过来的stu_id对应的记录
        LambdaUpdateWrapper<Account> lambdaUpdateWrapper = new LambdaUpdateWrapper<>();
        lambdaUpdateWrapper.eq(Account::getStuId, stuId);
        //如果记录不存在，抛出异常
        if (!(accountMapper.exists(lambdaUpdateWrapper))) {
            throw new LocalRuntimeException(ErrEnum.NO_USER.getErrCode(), ErrEnum.NO_USER.getErrMsg());
        }
        try {
            //执行更新操作
            accountMapper.update(null, lambdaUpdateWrapper.set(Account::getRole, 1));
            //返回成功信息
            return MyResponse.success("修改角色成功", 200, null);
        } catch (Exception e) {
            throw new LocalRuntimeException(ErrEnum.ERR_UPDATE.getErrCode(), ErrEnum.ERR_UPDATE.getErrMsg());
        }

    }

    //设置 阅卷人/管理员 组别
    @Override
    public MyResponse setGroup(String stuId, String grouped) {
        //学号不为空
        if (stuId == null) {
            throw new LocalRuntimeException(ErrEnum.NO_ARGS.getErrCode(), ErrEnum.NO_ARGS.getErrMsg());
        }
        //查询stu_id对应的记录
        LambdaUpdateWrapper<Account> lambdaUpdateWrapper = new LambdaUpdateWrapper<>();
        lambdaUpdateWrapper.eq(Account::getStuId, stuId);
        Account accountFromDB = accountMapper.selectOne(lambdaUpdateWrapper);
        //如果数据库不存在此人抛出异常
        if (accountFromDB == null) {
            throw new LocalRuntimeException(ErrEnum.NO_USER.getErrCode(), ErrEnum.NO_USER.getErrMsg());
        }
        //如果此人不是阅卷人或管理员抛出异常
        if (accountFromDB.getRole() == 0) {
            throw new LocalRuntimeException(ErrEnum.ERR_ROLE.getErrCode(), ErrEnum.ERR_ROLE.getErrMsg());
        }
        //执行设置操作
        accountMapper.update(null, lambdaUpdateWrapper.set(Account::getGrouped, grouped));
        //返回成功信息
        return MyResponse.success("设置阅卷人组别成功", 200, null);

    }


    //批量导入账号
    @Override
    public MyResponse importAccountInfo(String fileName, InputStream inputStream) throws Exception {
        //根据ExcelUtil工具类创建List集合，将excel中的信息存进userList中
        List<Account> userList = excelUtil.upload(fileName, inputStream);
        //遍历userList，在导入之前做去重，判断集合中的stu_id是否有与数据库中的stu_id重复的
        for (int i = 0; i < userList.size(); i++) {
            // 通过stu_id查找数据库中看这个用户信息是否存在
            LambdaQueryWrapper<Account> lambdaQueryWrapper = new LambdaQueryWrapper<>();
            lambdaQueryWrapper.eq(Account::getStuId, userList.get(i).getStuId());
            Account one = accountMapper.selectOne(lambdaQueryWrapper);
            //若有重复的用户信息
            if (one != null) {
                // 更新数据库中的用户信息
                accountMapper.updateById(userList.get(i));
                // 移除更新后的用户
                userList.remove(i);
                // 因为移除了，所以userList大小减了一而循环加了一，所以要减回去
                i = i - 1;
            }
        }
        //向数据库插入数据
        int flag = 0;
        int num = 0;
        for (Account account : userList) {
            //excel导入时去重操作，保证excel表中没有相同stu_id记录被导入
            //如果数据库中存在stu_id与要插入的stu_id相同记录，则跳过，插入下一行；如果没有，执行插入操作
            LambdaQueryWrapper<Account> lambdaQueryWrapper = new LambdaQueryWrapper<>();
            lambdaQueryWrapper.eq(Account::getStuId, account.getStuId());
            Long count = accountMapper.selectCount(lambdaQueryWrapper);
            //判断是否有重复记录，若没有
            if (count == 0) {
                //执行插入操作
                flag = accountMapper.insert(account);

            }
            //若有，什么都不做，等同于跳过这条记录
            else {
                num++;
            }
        }
        if (flag != 0) {
            return MyResponse.success("导入成功", 200, null);
        }
        if (num == userList.size()) {
            throw new LocalRuntimeException(ErrEnum.REPEATED_ACCOUNTS.getErrCode(), ErrEnum.REPEATED_ACCOUNTS.getErrMsg());
        } else {
            throw new LocalRuntimeException(ErrEnum.ERR_IMPORT.getErrCode(), ErrEnum.ERR_IMPORT.getErrMsg());
        }
    }

    //删除账号
    @Override
    public MyResponse deleteAccount(Account account) {

        //删除账号
        LambdaQueryWrapper<Account> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Account::getStuId, account.getStuId());
        if (!(accountMapper.exists(lambdaQueryWrapper))) {
            throw new LocalRuntimeException(ErrEnum.NO_USER.getErrCode(), ErrEnum.NO_USER.getErrMsg());
        }
        accountMapper.delete(lambdaQueryWrapper);
        //删除账号下关联的题目
        LambdaQueryWrapper<Answer> answerLambdaQueryWrapper = new LambdaQueryWrapper<>();
        answerLambdaQueryWrapper.eq(Answer::getStuId, account.getStuId());
        if (answerMapper.exists(answerLambdaQueryWrapper)) {
            answerMapper.delete(answerLambdaQueryWrapper);
        }
        //返回成功信息
        return MyResponse.success("删除账号成功", 200, null);
    }

    //得到阅卷人阅卷信息
    @Override
    public MyResponse getJudger(Long unitId) {

        if (unitId == null) {
            throw new RuntimeException("传递的参数为空");
        }

        //新建Map，用来存放data信息
        Map<String, Object> map = new HashMap<>();
        //新建List，用来存放具体阅卷人阅卷信息
        List<JudgerInfo> judgerInfos = new ArrayList<>();
        //查询数据库中所有需要批改的题目数，并存放到map中
        Long totalJudgedNum = answerMapper.selectCount(null);
        map.put("total_judged_num", totalJudgedNum);
        //查询数据库中所有已经批改完的题目数，并存放到map中
        Long totalFinishedNum = answerMapper.selectAllFinishedCount(unitId);
        map.put("total_finished_num", totalFinishedNum);

        //查询比赛名称返回给前端作渲染
        LambdaQueryWrapper<Unit> lambdaUnitQueryWrapper = new LambdaQueryWrapper<>();
        lambdaUnitQueryWrapper.eq(Unit::getId, unitId);
        Unit unit = unitMapper.selectOne(lambdaUnitQueryWrapper);
        map.put("unit_name", unit.getUnitName());

        //得到阅卷人账号信息，并遍历
        LambdaQueryWrapper<Account> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Account::getRole, 1);
        List<Account> judgerList = accountMapper.selectList(lambdaQueryWrapper);
        for (Account account :
                judgerList) {
            //查询当前阅卷人已经批改完的题目数
            Long finishedCorrectNum = answerMapper.selectFinishedCount(unitId, account.getStuId());

            //实例化一个JudgerInfo,用来存放当前阅卷人阅卷信息
            JudgerInfo judgerInfo = new JudgerInfo();
            judgerInfo.setJudgerId(account.getStuId());
            judgerInfo.setJudgerName(account.getStuName());
            judgerInfo.setFinishedCorrectNum(finishedCorrectNum);
            judgerInfo.setGrouped(account.getGrouped());
            //将当前阅卷人阅卷信息加入到judgerInfos中
            judgerInfos.add(judgerInfo);
        }
        //将阅卷人阅卷信息存到map中
        map.put("judger_list", judgerInfos);

        return MyResponse.success("得到阅卷人阅卷信息", 200, map);
    }

    @Override
    public MyResponse updatePassword(String stuId, String password) {

        LambdaQueryWrapper<Account> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Account::getStuId, stuId);
        Account accountFromDB = accountMapper.selectOne(queryWrapper);

        //如果用户不存在
        if (accountFromDB == null) {
            throw new LocalRuntimeException(ErrEnum.NO_USER.getErrCode(), ErrEnum.NO_USER.getErrMsg());
        }


        UpdateWrapper<Account> accountUpdateWrapper = new UpdateWrapper<>();
        accountUpdateWrapper.eq("stu_id", stuId);
        Account account = new Account();
        String md5password = DigestUtils.md5DigestAsHex(password.getBytes());
        account.setPassword(md5password);
        accountMapper.update(null, accountUpdateWrapper.set("md5password", md5password));
        return MyResponse.success("重置密码成功", 200, null);
    }

    //设置阅卷人
    @Override
    public MyResponse setJudger(Account account) {

        //查询传过来的stu_id对应的记录
        LambdaUpdateWrapper<Account> lambdaUpdateWrapper = new LambdaUpdateWrapper<>();
        lambdaUpdateWrapper.eq(Account::getStuId, account.getStuId());
        //如果记录不存在，抛出异常
        if (!(accountMapper.exists(lambdaUpdateWrapper))) {
            throw new LocalRuntimeException(ErrEnum.NO_USER.getErrCode(), ErrEnum.NO_USER.getErrMsg());
        }
        try {
            //执行更新操作
            accountMapper.update(null, lambdaUpdateWrapper.set(Account::getRole, 1));
            //返回成功信息
            return MyResponse.success("修改角色成功", 200, null);
        } catch (Exception e) {
            throw new LocalRuntimeException(ErrEnum.ERR_UPDATE.getErrCode(), ErrEnum.ERR_UPDATE.getErrMsg());
        }
    }

    @Override
    public MyResponse getUncorrectProblemList() {
        List<Map<String,Object>> list = new ArrayList<>();

        List<Problem> problemList = problemMapper.selectList(null);
        for (Problem problem :
                problemList) {
            Map<String,Object> map = new HashMap<>();
            map.put("problem_id",problem.getId());
            map.put("problem_description",problem.getProblemDescription());
            int uncorrectNum = 0;
            List<Answer> answerList = answerMapper.selectList(Wrappers.<Answer>lambdaQuery()
                    .eq(Answer::getProblemId, problem.getId()));
            for (Answer answer :answerList) {
                if (!answer.getAnswer().equals(problem.getAnswer())) {
                    uncorrectNum++;
                }
            }
            map.put("uncorrect_num",uncorrectNum);
            list.add(map);
        }
        return MyResponse.success("获取错题统计情况成功",200,list);
    }

    @Override
    public MyResponse getUnccorectProblemInfo(String stuId) {
        List<Map<String, Object>> list = new ArrayList<>();
        Integer unitScore = 0;
        Integer uncorrectProblemNum = 0;
        Integer problemNum = 0;
        List<Unit> unitList = unitMapper.selectList(null);
        for (Unit unit :
                unitList) {
            Map<String, Object> map = new HashMap<>();
            map.put("unit_id", unit.getId());
            map.put("unit_name", unit.getUnitName());

            List<Problem> problemList = problemMapper.selectList(Wrappers.<Problem>lambdaQuery()
                    .eq(Problem::getUnitId, unit.getId()));
            for (Problem problem :
                    problemList) {
                problemNum = problemList.size();
                if (answerMapper.exists(Wrappers.<Answer>lambdaQuery()
                        .eq(Answer::getStuId, stuId)
                        .eq(Answer::getProblemId, problem.getId()))) {
                    unitScore += answerMapper.selectOne(Wrappers.<Answer>lambdaQuery()
                            .eq(Answer::getStuId, stuId)
                            .eq(Answer::getProblemId, problem.getId())).getCorrectScore();
                    String answer = answerMapper.selectOne(Wrappers.<Answer>lambdaQuery()
                            .eq(Answer::getStuId, stuId)
                            .eq(Answer::getProblemId, problem.getId())).getAnswer();
                    if (!answer.equals(problem.getAnswer())) {
                        uncorrectProblemNum++;
                        map.put("problem_id", problem.getId());
                        map.put("problem_name", problem.getProblemDescription());
                    }
                }
            }
            map.put("unit_score", unitScore);
            map.put("total_score", unit.getTotalScore());
            map.put("uncorrect_problem_num",uncorrectProblemNum);
            map.put("total_problem_num",problemNum);
            list.add(map);
        }
        return MyResponse.success("获取单个学生错题统计情况成功", 200, list);
    }


}
