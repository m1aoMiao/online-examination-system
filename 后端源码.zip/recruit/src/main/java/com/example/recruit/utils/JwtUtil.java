package com.example.recruit.utils;


import com.example.recruit.enetity.Account;
import io.jsonwebtoken.*;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Objects;
import java.util.UUID;

@Component
public class JwtUtil {
    private static final long time = 1000*60*60*24 ;
    private static final String signature = "9991morF0GgnahZ";

    public static String createToken(Account account){
        JwtBuilder jwtBuilder = Jwts.builder();
        String jwToken = jwtBuilder
                //链式编程 添加头
                .setHeaderParam("typ","JWT")
                .setHeaderParam("alg","HS256")
                //payload 载荷
                .claim("stu_id",account.getStuId())
                .claim("role",account.getRole())
                //主题
                .setSubject("admin")
                //有效期
                .setExpiration(new Date(System.currentTimeMillis()+time))
                .setId(UUID.randomUUID().toString())
                //signature签名
                .signWith(SignatureAlgorithm.HS256,signature)
                //拼接前面三个
                .compact();
        return jwToken;
    }

    public static boolean checkToken(String token) {
        if (Objects.equals(token, "") || token == null) {
            return false;
        }

        try {
            //解析后拿到存有token信息的集合
            Jws<Claims> claimsJws1 = Jwts.parser().setSigningKey(signature).parseClaimsJws(token);

        } catch (Exception e) {
            System.out.println("【Error】token解密异常");
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
