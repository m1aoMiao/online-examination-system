package com.example.recruit.info;

import lombok.Data;

/**
 * @author scarborough
 * @creat 2022/11/9 - 14:43
 */
@Data
public class StuInfo {

    private String stuId;
    private String stuName;
    //此人已经完成的问题数
    private Integer finishedQuestionNum;
    //此人总共需要完成的问题数
    private Long totalQuestionNum;
    //此人已经被批改的问题数
    private Integer finishedCorrectNum;
    private Integer unitScore;
    private Integer totalScore;
}
