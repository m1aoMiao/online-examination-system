package com.example.recruit.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.example.recruit.enetity.Account;
import com.example.recruit.exception.LocalRuntimeException;
import com.example.recruit.response.ErrEnum;
import com.example.recruit.response.MyResponse;
import com.example.recruit.service.AccountService;
import com.example.recruit.utils.JwtUtil;
import com.example.recruit.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Slf4j
@RestController
public class LoginController {
    @Autowired
    private AccountService accountService;
    @Autowired
    private RedisUtil redisUtil;

    /**
     * 退出登录
     */
    @PostMapping("/exit")
    public MyResponse exitLogin(HttpServletRequest request){
        String token = request.getHeader("token");
        RedisUtil.deleteValue("token");
        return MyResponse.success("退出登录成功",200,null);
    }


    /**
     * 登陆
     */
    @PostMapping("/login")
    public MyResponse login(@RequestBody Account account) {
//        System.out.println(account);
        //密码进行md5加密
        String password = account.getPassword();
        password = DigestUtils.md5DigestAsHex(password.getBytes());

        //根据用户Id查询数据库
        LambdaQueryWrapper<Account> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Account::getStuId, account.getStuId());
        Account accountFromDB = accountService.getOne(queryWrapper);

        //没查询到用户
        if (accountFromDB == null) {
            throw new LocalRuntimeException(ErrEnum.NO_USER.getErrCode(), ErrEnum.NO_USER.getErrMsg());
        }

        //密码错误
        if (!accountFromDB.getPassword().equals(password)) {
            throw new LocalRuntimeException(ErrEnum.NO_PERMISSION.getErrCode(), ErrEnum.NO_PERMISSION.getErrMsg());
        }

        //登陆成功，创建token
        String token = JwtUtil.createToken(accountFromDB);

        RedisUtil.saveValue(token, accountFromDB, 30, TimeUnit.DAYS);
        Map<String, Object> map = new HashMap<>();
        map.put("stu_id", accountFromDB.getStuId());
        map.put("user_name", accountFromDB.getStuName());
        map.put("role", accountFromDB.getRole().toString());
        map.put("token", token);
        return MyResponse.success("登陆成功", 200, map);
    }


    /**
     * 注册
     */
    @PostMapping("/register")
    public MyResponse register(@RequestBody Account account) {

        //密码进行md5加密
        String password = account.getPassword();
        password = DigestUtils.md5DigestAsHex(password.getBytes());
        account.setPassword(password);

        LambdaQueryWrapper<Account> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Account::getStuId, account.getStuId());
        Account accountFromDbB = accountService.getOne(queryWrapper);

        //如果用户已存在
        if (accountFromDbB != null) {
            throw new LocalRuntimeException(ErrEnum.REPEATED_USER.getErrCode(), ErrEnum.REPEATED_USER.getErrMsg());
        }

        account.setRole(0);
        accountService.save(account);

        return MyResponse.success("注册成功", 200, null);
    }

    /**
     * 重设密码
     */
    @PostMapping("/updatePassword")
    public MyResponse updatePassword(@RequestParam String stuId, @RequestParam String oldPassword, @RequestParam String newPassword) {

        LambdaQueryWrapper<Account> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(Account::getStuId, stuId);
        Account accountFromDbB = accountService.getOne(queryWrapper);

        //md5加密
        oldPassword = DigestUtils.md5DigestAsHex(oldPassword.getBytes());
        newPassword = DigestUtils.md5DigestAsHex(newPassword.getBytes());

        //如果用户不存在
        if (accountFromDbB == null) {
            throw new LocalRuntimeException(ErrEnum.NO_USER.getErrCode(), ErrEnum.NO_USER.getErrMsg());
        }

        //密码错误
        if (!accountFromDbB.getPassword().equals(oldPassword)) {
            throw new LocalRuntimeException(ErrEnum.NO_PERMISSION.getErrCode(), ErrEnum.NO_PERMISSION.getErrMsg());
        }

        //更新密码
        UpdateWrapper<Account> accountUpdateWrapper = new UpdateWrapper<>();
        accountUpdateWrapper.eq("stu_id", stuId);
        Account account = new Account();
        account.setPassword(newPassword);
        accountService.update(account, accountUpdateWrapper);
        return MyResponse.success("修改密码成功", 200, null);
    }

    //获取比赛列表
    @GetMapping("/getUnit")
    public MyResponse getUnit(){
        return MyResponse.success("获取比赛列表成功", 200, accountService.getUnit());

    }


}