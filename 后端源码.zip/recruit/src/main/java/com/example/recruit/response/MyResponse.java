package com.example.recruit.response;

import com.example.recruit.exception.LocalRuntimeException;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author scarborough
 * @creat 2022/11/2 - 19:44
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MyResponse {

    //是否成功
    private Boolean success;
    //状态码
    private Integer status;
    //提示信息
    private String msg;
    //数据
    private Object data;

    //自定义成功返回结果
    public static MyResponse success(String msg, Integer status, Object data){
        MyResponse response = new MyResponse();
        response.setSuccess(true);
        response.setStatus(status);
        response.setMsg(msg);
        response.setData(data);
        return response;
    }


    //自定义异常返回结果
    public static MyResponse error(LocalRuntimeException e) {
        MyResponse result = new MyResponse();
        result.setMsg(e.getErrorMsg());
        result.setStatus(e.getErrorCode());
        result.setSuccess(false);
        result.setData(null);
        return result;
    }


}
