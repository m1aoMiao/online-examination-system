package com.example.recruit.service;

import com.example.recruit.enetity.Account;
import com.example.recruit.enetity.Unit;
import com.example.recruit.response.MyResponse;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author scarborough
 * @creat 2022/11/5 - 14:08
 */
public interface AdminService {
    //新建比赛
    MyResponse addUnit(Unit unit);

    //修改比赛
    MyResponse updateUnit(Long id, Unit unit);

    //删除比赛
    MyResponse deleteUnit(Long unitId);

    //上传题目
    MyResponse addProblem(Long unitId, String problemDescription, Integer problemType, Integer problemScore, Integer problemGroup, String optionA, String optionB, String optionC, String optionD, MultipartFile[] picture, String answer) throws IOException;
    MyResponse addProblem(Long unitId, String problemDescription, Integer problemType, Integer problemScore, Integer problemGroup, String optionA, String optionB, String optionC, String optionD, String answer) throws IOException;

    //修改题目
    MyResponse updateProblem(Long problemId, String problemDescription, Integer problemType, Integer problemScore, Integer problemGroup, String optionA, String optionB, String optionC, String optionD, MultipartFile[] picture) throws IOException;

    //删除题目
    MyResponse deleteProblem(Long problemId);

    //修改角色
    MyResponse updateRole(String stuId);

    //设置阅卷人组别
    MyResponse setGroup(String stuId, String grouped);

    //批量导入账号信息
    MyResponse importAccountInfo(String fileName, InputStream inputStream) throws Exception;

    //删除账号
    MyResponse deleteAccount(Account account);

    //得到阅卷人阅卷信息
    MyResponse getJudger(Long unitId);

    //管理员强制更改密码
    MyResponse updatePassword(String stuId, String password);

    //设置阅卷人
    MyResponse setJudger(Account account);

    MyResponse getUncorrectProblemList();

    MyResponse getUnccorectProblemInfo(String stuId);
}
