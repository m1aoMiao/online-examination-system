package com.example.recruit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.recruit.enetity.Account;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author scarborough
 * @creat 2022/11/5 - 14:28
 */
@Mapper
public interface AccountMapper extends BaseMapper<Account> {
}
