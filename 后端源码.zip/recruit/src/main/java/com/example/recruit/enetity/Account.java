package com.example.recruit.enetity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author scarborough
 * @creat 2022/11/5 - 13:57
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "account")
public class Account implements Serializable {
    @TableId(value = "uid", type = IdType.ASSIGN_ID)
    private Long id;

    @TableField(value = "stu_id")
    private String stuId;

    private String stuName;

    @TableField("md5password")
    private String password;

    private Integer role;

    private String grouped;

    private Integer frontEndScore;
    private Integer backEndScore;
    private Integer pythonScore;
    private Integer algorithmScore;
    private Integer securityScore;

}
