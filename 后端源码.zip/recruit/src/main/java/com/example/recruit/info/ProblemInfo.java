package com.example.recruit.info;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

/**
 * @author scarborough
 * @creat 2022/11/9 - 16:06
 */
@Data
public class ProblemInfo {

    private Long problemId;
    private String problemDescription;
    private String problemType;
    private Integer problemScore;
    private String problemGroup;
    private String answer;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String pictureUrl;
}
