package com.example.recruit.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.recruit.enetity.Account;
import com.example.recruit.enetity.Answer;
import com.example.recruit.enetity.Problem;
import com.example.recruit.enetity.Unit;
import com.example.recruit.exception.LocalRuntimeException;
import com.example.recruit.mapper.AccountMapper;
import com.example.recruit.mapper.AnswerMapper;
import com.example.recruit.mapper.ProblemMapper;
import com.example.recruit.mapper.UnitMapper;
import com.example.recruit.response.ErrEnum;
import com.example.recruit.service.StudentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Slf4j
@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private ProblemMapper problemMapper;
    @Autowired
    private AnswerMapper answerMapper;
    @Autowired
    private UnitMapper unitMapper;
    @Autowired
    private AccountMapper accountMapper;


    //拉取题目列表
    @Override
    public Map<String, Object> getList(String stuId, Long unitId) {
        log.info("unitId: "+unitId);

        Integer unitScore = 0;

        List<Map<String, Object>> problemList = new ArrayList<>();

        Map<String, Object> map = new HashMap<>();
//        Map<String,Map<String,Object>> problemMap = new HashMap<>();

        QueryWrapper<Problem> queryWrapper0 = new QueryWrapper<Problem>();
        queryWrapper0.eq("unit_id", unitId);
        List<Problem> problems = problemMapper.selectList(queryWrapper0);

        // 循环获取此比赛下的每一个题目
        for (Problem problem : problems) {
            Map<String, Object> problemMap = new HashMap<>();
            problemMap.put("problem_id", problem.getId());
            problemMap.put("problem_description", problem.getProblemDescription());
            problemMap.put("problem_type", problem.getProblemType());
            problemMap.put("problem_group", problem.getProblemGroup());
            problemMap.put("problem_total_score", problem.getProblemScore());
            problemMap.put("A", problem.getOptionA());
            problemMap.put("B", problem.getOptionB());
            problemMap.put("C", problem.getOptionC());
            problemMap.put("D", problem.getOptionD());
            problemMap.put("picture_url", problem.getPictureUrl());
            problemMap.put("correct_answer", problem.getAnswer());
            QueryWrapper<Answer> queryWrapper1 = new QueryWrapper<>();
            queryWrapper1.eq("stu_id", stuId);
            queryWrapper1.eq("problem_id", problem.getId());
            // 获取到每个题目的答案，如果有答案，就返回，如果没答案，返回空
            Answer answer = answerMapper.selectOne(queryWrapper1);
            if (answer != null) {
                problemMap.put("answer", answer.getAnswer());
                problemMap.put("problem_score", answer.getCorrectScore());
                unitScore += answer.getCorrectScore();
            } else {
                problemMap.put("answer", null);
                problemMap.put("problem_score", null);
            }
            problemList.add(problemMap);
        }

        map.put("problem_list", problemList);

        Unit unit = unitMapper.selectById(unitId);

        map.put("unit_name", unit.getUnitName());
        map.put("unit_description", unit.getUnitDescription());
        map.put("unit_score", unitScore);
        map.put("total_score", unitMapper.selectById(unitId).getTotalScore());
        return map;
    }

    //学生提交答案
    @Override
    public void commitAnswer(String stuId, Long unitId, Long problemId, String answer) {

        if (
                LocalDateTime.now().isAfter(unitMapper.selectById(unitId).getEndTime()) ||
                        LocalDateTime.now().isBefore(unitMapper.selectById(unitId).getStartTime())
        ){
            throw new LocalRuntimeException(ErrEnum.UNAUTHORIZED_TIME.getErrCode(),
                    ErrEnum.UNAUTHORIZED_TIME.getErrMsg());
        }
        UpdateWrapper<Answer> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("unit_id", unitId);
        updateWrapper.eq("stu_id", stuId);
        updateWrapper.eq("problem_id", problemId);
        if (answerMapper.exists(updateWrapper)) {
            answerMapper.update(null, updateWrapper.set("answer", answer));
        } else {
            answerMapper.insert(new Answer(unitId, stuId, problemId, answer, null, null));
        }

        // 自动批改
        Problem problem = problemMapper.selectById(problemId);
        if (answer.equals(problem.getAnswer())) {
            answerMapper.update(null, Wrappers.<Answer>lambdaUpdate()
                    .eq(Answer::getStuId, stuId)
                    .eq(Answer::getProblemId, problemId)
                    .set(Answer::getCorrectScore, problem.getProblemScore()));
        } else {
            answerMapper.update(null, Wrappers.<Answer>lambdaUpdate()
                    .eq(Answer::getStuId, stuId)
                    .eq(Answer::getProblemId, problemId)
                    .set(Answer::getCorrectScore, 0));
        }
    }

    @Override
    public List<Map<String, Object>> getHistoryScore(String stuId) {

        List<Map<String, Object>> list = new ArrayList<>();
        List<Unit> unitList = unitMapper.selectList(null);
        log.info(unitList.toString());
        for (Unit unit :
                unitList) {
            Integer unitScore = 0;

            Map<String, Object> map = new HashMap<>();
            map.put("unit_id", unit.getId());
            map.put("unit_name", unit.getUnitName());

            List<Problem> problemList = problemMapper.selectList(Wrappers.<Problem>lambdaQuery()
                    .eq(Problem::getUnitId, unit.getId()));
            if(problemList.size()!=0){
                for (Problem problem :
                        problemList) {
                    if (answerMapper.exists(Wrappers.<Answer>lambdaQuery()
                            .eq(Answer::getStuId, stuId)
                            .eq(Answer::getProblemId, problem.getId()))) {
                        unitScore += answerMapper.selectOne(Wrappers.<Answer>lambdaQuery()
                                .eq(Answer::getStuId, stuId)
                                .eq(Answer::getProblemId, problem.getId())).getCorrectScore();
                    }
                }
            }

            map.put("unit_score", unitScore);
            map.put("total_score", unit.getTotalScore());
            map.put("stuId",stuId);
            map.put("stu_name", accountMapper.selectOne(Wrappers.<Account>lambdaQuery()
                    .eq(Account::getStuId, stuId)).getStuName());
            map.put("start_time", unit.getStartTime());
            map.put("end_time", unit.getEndTime());
            list.add(map);
        }
        return list;
    }
}
