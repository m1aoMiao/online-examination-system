package com.example.recruit.controller;


import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.example.recruit.enetity.Account;
import com.example.recruit.enetity.Problem;
import com.example.recruit.mapper.ProblemMapper;
import com.example.recruit.response.MyResponse;
import com.example.recruit.service.StudentService;
import com.example.recruit.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
//@GetMapping("/normal")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private ProblemMapper problemMapper;

    //获取题目列表（兼答题详情历史）
    @GetMapping("/normal/getList")
    public MyResponse questionList(HttpServletRequest request, @RequestParam Long unitId){
        String token = request.getHeader("token");
        Account account = RedisUtil.getValue(token);
        return MyResponse.success("获取题目列表成功", 200, studentService.getList(account.getStuId(), unitId));
    }

    //学生提交答案(同时自动批改)
    @PostMapping("/normal/commitAnswer")
    public MyResponse commitAnswer(HttpServletRequest request, @RequestParam Long unitId ,@RequestBody Object [] array){
        String token = request.getHeader("token");
        Account account = RedisUtil.getValue(token);
        String stuId = account.getStuId();
        for (Object o : array) {
            Map data = (Map) o;
            String answer = data.get("answer").toString();
            Long problemId = Long.valueOf(data.get("problemId").toString());
            studentService.commitAnswer(stuId, unitId, problemId, answer);
        }
        return MyResponse.success("提交答案成功", 200, null);
    }

    @GetMapping("/normal/score/list")
    public MyResponse scoreHistory(HttpServletRequest request){
        String token = request.getHeader("token");
        Account account = RedisUtil.getValue(token);
        String stuId = account.getStuId();

        return MyResponse.success("获取历史成绩成功", 200, studentService.getHistoryScore(stuId));
    }



}
