package com.example.recruit.interceptor;

import com.example.recruit.utils.JwtUtil;
import com.example.recruit.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@Component
public class TokenInterceptor implements HandlerInterceptor {
    @Autowired
    JwtUtil jwtUtil;
    @Autowired
    RedisUtil redisUtil;

    @Override
    public boolean preHandle( HttpServletRequest request, HttpServletResponse response, Object handler) {
        // 注意：放行浏览器的预检请求
        log.info("进入预检");
        if ("OPTIONS".equals(request.getMethod())) {
            return true;
        }
        // 提取token
        String token = request.getHeader("token");
        // token验证
        //查看token是否为空 查看token是否合法
        if(JwtUtil.checkToken(token)) {

            log.info("【success】token与redis中的匹配成功");

            return true;

        }
        log.info("【error】 token与redis中的匹配失败");
//            throw new Exception("【error】 token与redis中的匹配失败");
        // 验证失败，拦截请求
        return false;
    }

}
