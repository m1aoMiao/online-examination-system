package com.example.recruit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.recruit.enetity.Answer;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


/**
 * @author scarborough
 * @creat 2022/11/7 - 20:50
 */
@Mapper
public interface AnswerMapper extends BaseMapper<Answer> {
    @Select("SELECT count(*) FROM `answer` WHERE correct_score IS NOT NULL AND unit_id = #{unitId}")
    Long selectAllFinishedCount(Long unitId);

    @Select("SELECT COUNT(*) FROM `answer` WHERE (judger_id,unit_id) = (#{judger_id},#{unit_id}) AND correct_score IS NOT NULL")
    Long selectFinishedCount(@Param("unit_id") Long unitId, @Param("judger_id") String judgerId);

    @Select("SELECT COUNT(DISTINCT stu_id) FROM answer ")
    Long selectTotalAnsweredAccountNum();

    @Select("SELECT COUNT(*) FROM answer WHERE stu_id = #{stuId} AND unit_id = #{unitId};")
    Integer selectFinishedQuestionNum(String stuId,Long unitId);

    @Select("SELECT COUNT(*) FROM `answer` WHERE (stu_id,unit_id) = (#{stu_id},#{unit_id}) AND correct_score IS NOT NULL")
    Integer selectFinishedCorrectNum(@Param("unit_id") Long unitId, @Param("stu_id") String stuId);

    @Select("SELECT answer FROM answer WHERE (stu_id,problem_id) = (#{stuId},#{problemId})")
    String selectProblemAnswer(@Param("stuId") String stuId, @Param("problemId") Long problemId);
}
