package com.example.recruit.service;


import com.example.recruit.info.ScoreInfo;
import com.example.recruit.response.MyResponse;

import java.util.List;

/**
 * @author scarborough
 * @creat 2022/11/8 - 18:55
 */
public interface JudgerService {
    //阅卷人-得到答题信息列表
    MyResponse getList(Long unitId);

    //阅卷人-得到具体某个人的答题情况
    MyResponse getOne(Long unitId, String stuId);

    //阅卷人-批改
    MyResponse correct(Long unitId, String stuId, List<ScoreInfo> scoreInfos, String judgerId);
}
