package com.example.recruit.enetity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author scarborough
 * @create 2022/11/4 - 15:44
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Problem {
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    private Long unitId;

    private String problemDescription;

    private Integer problemType;

    private Integer problemScore;

    private Integer problemGroup;

    @TableField(value = "A")
    private String optionA;

    @TableField(value = "B")
    private String optionB;

    @TableField(value = "C")
    private String optionC;

    @TableField(value = "D")
    private String optionD;

    private String pictureUrl;
    private String answer;

    public Problem(Long unitId, String problemDescription, Integer problemType, Integer problemScore,Integer problemGroup, String optionA, String optionB, String optionC, String optionD, String pictureUrl, String answer) {
        this.unitId = unitId;
        this.problemDescription = problemDescription;
        this.problemType = problemType;
        this.problemScore = problemScore;
        this.problemGroup = problemGroup;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.pictureUrl = pictureUrl;
        this.answer = answer;
    }

    public Problem(Long unitId, String problemDescription, Integer problemType , Integer problemScore, Integer problemGroup,String pictureUrl, String answer) {
        this.unitId = unitId;
        this.problemDescription = problemDescription;
        this.problemType = problemType;
        this.problemScore = problemScore;
        this.problemGroup = problemGroup;
        this.pictureUrl = pictureUrl;
        this.answer = answer;
    }
}
