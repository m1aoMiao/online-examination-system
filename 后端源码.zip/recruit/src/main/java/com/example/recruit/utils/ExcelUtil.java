package com.example.recruit.utils;

import com.example.recruit.enetity.Account;
import com.example.recruit.exception.LocalRuntimeException;
import com.example.recruit.response.ErrEnum;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.util.DigestUtils;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


/**
 * @author scarborough
 * @creat 2022/11/6 - 17:46
 */
@Component
public class ExcelUtil {

    // 将表格中的数据添加到List集合中
    public List<Account> upload(String fileName, InputStream inputStream) throws Exception{
        Workbook workbook = getWorkbook(fileName,inputStream);
        List<Account> userList = new ArrayList<>();
        // 获取sheet值
        int number = workbook.getNumberOfSheets();
        for (int i = 0; i < number; i++) {
            // 获取表格页码
            Sheet sheet = workbook.getSheetAt(i);
            //若表格页码不为空，执行
            if (sheet != null){
                // 获取该页表共有多少行
                int rowNum = sheet.getLastRowNum();
                // 一般来说第一行是标题,所以第二行开始读取
                for (int j = 1; j <= rowNum; j++) {
                    // 获取表格行
                    Row row = sheet.getRow(j);
                    Account account = new Account();
                    // 将该单元格获取出来的值设为String类型
                    row.getCell(0).setCellType(Cell.CELL_TYPE_STRING);
                    // 获取表格单元格并给Account设置值
                    account.setStuId(row.getCell(0).getStringCellValue());
                    // 将该单元格获取出来的值设为String类型
                    row.getCell(1).setCellType(Cell.CELL_TYPE_STRING);
                    // 获取表格单元格并给Account设置值
                    account.setStuName(row.getCell(1).getStringCellValue());
                    // 将该单元格获取出来的值设为String类型
                    row.getCell(2).setCellType(Cell.CELL_TYPE_STRING);
                    // 获取表格单元格并给Account设置值
                    account.setPassword(DigestUtils.md5DigestAsHex(row.getCell(2).getStringCellValue().getBytes()));
                    // 将该单元格获取出来的值设为Integer类型
                    row.getCell(3).setCellType(Cell.CELL_TYPE_NUMERIC);
                    // 获取表格单元格并给Account设置值
                    account.setRole((int) row.getCell(3).getNumericCellValue());
                    //并不是所有的组别都要设置，普通用户为空，就不用设置
                    if(row.getCell(4)!=null){
                        // 将该单元格获取出来的值设为String类型
                        row.getCell(4).setCellType(Cell.CELL_TYPE_STRING);
                        // 获取表格单元格并给Account设置值
                        account.setGrouped(row.getCell(4).getStringCellValue());
                    }


                    //向List集合中添加账号信息
                    userList.add(account);
                }
            }
        }
        return userList;

    }

    // 判断传入的文件是哪种类型的excel文件
    public Workbook getWorkbook(String fileName, InputStream inputStream) throws Exception{
        Workbook workbook;
        //得到文件的后缀名，加“.”
        String name = fileName.substring(fileName.lastIndexOf("."));
        //只接收“.xls”结尾和“.xlsx”结尾的文件
        if (".xls".equals(name)){
            workbook = new HSSFWorkbook(inputStream);
        }else if (".xlsx".equals(name)){
            workbook = new XSSFWorkbook(inputStream);
        }else {
            throw new LocalRuntimeException(ErrEnum.ERR_FILE_FORM.getErrCode(), ErrEnum.ERR_FILE_FORM.getErrMsg());
        }
        return workbook;
    }

}
