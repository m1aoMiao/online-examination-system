package com.example.recruit.info;

import lombok.Data;

/**
 * @author scarborough
 * @creat 2022/11/8 - 16:51
 */
@Data
public class JudgerInfo {
    private String judgerId;
    private String judgerName;
    //当前阅卷人已经批改完的题目数
    private Long finishedCorrectNum;
    private String grouped;
}
