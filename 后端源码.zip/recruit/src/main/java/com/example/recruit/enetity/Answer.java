package com.example.recruit.enetity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author scarborough
 * @creat 2022/11/7 - 20:40
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Answer {
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    private Long unitId;
    private String stuId;

    private Long problemId;
    //学生的答案
    private String answer;
    //得分
    private Integer correctScore;
    //阅卷人ID
    private String judgerId;

    public Answer(Long unitId, String stuId, Long problemId, String answer, Integer correctScore, String judgerId) {
        this.unitId = unitId;
        this.stuId = stuId;
        this.problemId = problemId;
        this.answer = answer;
        this.correctScore = correctScore;
        this.judgerId = judgerId;
    }
}
