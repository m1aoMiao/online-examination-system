package com.example.recruit.config;

import com.example.recruit.interceptor.AreaInterceptor;
import com.example.recruit.interceptor.TokenInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.annotation.Resource;

/**
 * @author: scarborough
 * @datetime: 2023/9/27 - 10:10
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Resource
    private TokenInterceptor tokenInterceptor;
    @Resource
    private AreaInterceptor areaInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        //添加tokenHandler拦截器 全部拦截 排除"/admin/login"
        registry.addInterceptor(tokenInterceptor)
                .addPathPatterns("/**")
                .excludePathPatterns("/login")
                .excludePathPatterns("/register")
                .excludePathPatterns("/updatePassword");
        //添加请求头
        registry.addInterceptor(areaInterceptor)
                .addPathPatterns("/**");
    }
}
