package com.example.recruit.info;

import lombok.Data;

/**
 * @author scarborough
 * @creat 2022/11/10 - 8:53
 */
@Data
public class ScoreInfo {
    private Long problemId;
    private Integer score;
}
