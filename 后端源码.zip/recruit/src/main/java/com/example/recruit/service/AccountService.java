package com.example.recruit.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.example.recruit.enetity.Account;

import java.util.List;

public interface AccountService extends IService<Account> {
    List<Object> getUnit();
}
