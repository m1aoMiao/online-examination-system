package com.example.recruit.controller;

import com.example.recruit.enetity.Account;
import com.example.recruit.enetity.Unit;
import com.example.recruit.exception.LocalRuntimeException;
import com.example.recruit.response.ErrEnum;
import com.example.recruit.response.MyResponse;
import com.example.recruit.service.AdminService;
import com.example.recruit.service.StudentService;
import com.example.recruit.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.jetbrains.annotations.NotNull;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;

/**
 * @author scarborough
 * @creat 2022/11/3 - 15:40
 */
@Slf4j
@RestController
@RequestMapping("/root")
public class AdminController {
    @Resource
    private AdminService adminService;
    @Resource
    private StudentService studentService;


    //新建比赛
    @PostMapping("/newUnit")
    public MyResponse newUnit(@RequestBody Unit unit, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }

        return adminService.addUnit(unit);
    }

    //修改比赛
    @PostMapping("/updateUnit")
    public MyResponse updateUnit(@RequestParam("unitId") @NotNull Long unitId, @RequestBody Unit unit, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.updateUnit(unitId, unit);
    }

    //删除比赛
    @PostMapping("/deleteUnit")
    public MyResponse deleteUnit(@RequestParam @NotNull Long unitId, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.deleteUnit(unitId);
    }

    //上传题目
    @PostMapping("/uploadproblem")
    public MyResponse uploadProblem(@RequestParam Long unitId,
                                    @RequestParam String problemDescription,
                                    @RequestParam Integer problemType,
                                    @RequestParam Integer problemGroup,
                                    @RequestParam Integer problemScore,
                                    @RequestParam String optionA,
                                    @RequestParam String optionB,
                                    @RequestParam String optionC,
                                    @RequestParam String optionD,
                                    @RequestParam MultipartFile[] picture,
                                    @RequestParam String answer,
                                    @NotNull HttpServletRequest httpServletRequest) throws IOException {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.addProblem(unitId, problemDescription, problemType, problemScore, problemGroup, optionA, optionB, optionC, optionD, picture, answer);
    }
    @PostMapping("/uploadproblem/nopicture")
    public MyResponse uploadProblem(@RequestParam Long unitId,
                                    @RequestParam String problemDescription,
                                    @RequestParam Integer problemType,
                                    @RequestParam Integer problemGroup,
                                    @RequestParam Integer problemScore,
                                    @RequestParam String optionA,
                                    @RequestParam String optionB,
                                    @RequestParam String optionC,
                                    @RequestParam String optionD,
                                    @RequestParam String answer,
                                    @NotNull HttpServletRequest httpServletRequest) throws IOException {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.addProblem(unitId, problemDescription, problemType, problemScore, problemGroup, optionA, optionB, optionC, optionD,answer);
    }

    //修改题目
    @PostMapping("/updateProblem")
    public MyResponse updateProblem(@RequestParam @NotNull Long problemId,
                                  @RequestParam String problemDescription,
                                  @RequestParam Integer problemType,
                                  @RequestParam Integer problemScore,
                                  @RequestParam Integer problemGroup,
                                  @RequestParam String optionA,
                                  @RequestParam String optionB,
                                  @RequestParam String optionC,
                                  @RequestParam String optionD,
                                  @RequestParam MultipartFile[] picture,
                                  @NotNull HttpServletRequest httpServletRequest) throws IOException {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.updateProblem(problemId, problemDescription, problemType, problemScore, problemGroup, optionA, optionB, optionC, optionD, picture);

    }

    //删除题目
    @PostMapping("/deleteProblem")
    public MyResponse deleteProblem(@RequestParam @NotNull Long problemId, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.deleteProblem(problemId);
    }

    //设置阅卷人
    @PostMapping("/updateRole")
    public MyResponse updateRole(@RequestParam String stuId, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account one = RedisUtil.getValue(token);
        if (one.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.updateRole(stuId);
    }

    //设置阅卷人组别
    @PostMapping("/setGroup")
    public MyResponse setGroup(@RequestParam String stuId, @RequestParam String grouped, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.setGroup(stuId, grouped);
    }

    //批量导入账号,通过excel导入
    @PostMapping("/bulkImportAccount")
    public MyResponse bulkImportAccount(@RequestParam MultipartFile accountFile, @NotNull HttpServletRequest httpServletRequest) throws Exception {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        //判断上传的文件是否为空
        if (accountFile.isEmpty()) {
            throw new RuntimeException("文件夹为空，重新上传");
            //执行文件上传，向数据库添加数据
        } else {
            //去掉文件后缀名，得到文件名
            String fileName = accountFile.getOriginalFilename();
            //得到文件输入流
            InputStream inputStream = accountFile.getInputStream();
            //若导入成功
            return adminService.importAccountInfo(fileName, inputStream);
        }
    }

    //删除账号
    @PostMapping("/deleteAccount")
    public MyResponse deleteAccount(@RequestBody Account account, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account one = RedisUtil.getValue(token);
        if (one.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.deleteAccount(account);
    }

    //得到阅卷人改卷信息
    @GetMapping("/getJudger")
    public MyResponse getJudger(@RequestParam Long unitId, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if(account.getRole()!=2){
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.getJudger(unitId);
    }

    //管理员强制重置密码
    @PostMapping("/updatePassword")
    public MyResponse updatePassword(@RequestParam String stuId, @RequestParam String password, @NotNull HttpServletRequest httpServletRequest) {
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }return adminService.updatePassword(stuId, password);

    }

    //设置阅卷人
    @PostMapping("/setJudger")
    public MyResponse setJudger(@RequestBody Account account, @NotNull HttpServletRequest httpServletRequest){
        String token = httpServletRequest.getHeader("token");
        Account one = RedisUtil.getValue(token);
        if (one.getRole() != 2) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.setJudger(account);

    }

    //获取学生成绩历史
    @GetMapping("/student-score/{stu_id}")
    public MyResponse getStuScoreHistory(@PathVariable("stu_id") String stuId,
                                         @NotNull HttpServletRequest httpServletRequest){
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() == 0) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return MyResponse.success("获取历史成绩成功", 200, studentService.getHistoryScore(stuId));
    }

    // 获取错题列表
    @GetMapping("/uncorrect/list")
    public MyResponse getUncorrectProList(@NotNull HttpServletRequest httpServletRequest){
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() ==0) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.getUncorrectProblemList();
    }

    // 获取错题列表(单个学生)
    @GetMapping("/uncorrect/list/{stu_id}")
    private MyResponse getOneUncorrectProList(@PathVariable("stu_id") String stuId,
                                           @NotNull HttpServletRequest httpServletRequest){
        String token = httpServletRequest.getHeader("token");
        Account account = RedisUtil.getValue(token);
        if (account.getRole() == 0) {
            throw new LocalRuntimeException(ErrEnum.UN_AUTHORIZED.getErrCode(), ErrEnum.UN_AUTHORIZED.getErrMsg());
        }
        return adminService.getUnccorectProblemInfo(stuId);
    }
}